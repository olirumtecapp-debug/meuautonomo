import { and, desc, eq, gte, lt, ne } from "drizzle-orm";
import { nanoid } from "nanoid";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import {
  appointments,
  availability,
  clients,
  expenses,
  notifications,
  payments,
  professionalProfiles,
  quoteItems,
  quotes,
  requestAttachments,
  requests,
  services,
} from "../drizzle/schema";
import { createNotification, getDb, getProfileBySlug, getProfileByUserId } from "./db";
import { storagePut } from "./storage";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";

const modality = z.enum(["presencial", "endereco", "online", "hibrido"]);
const paymentMethod = z.enum(["pix", "dinheiro", "cartao", "transferencia", "outro"]);
const appointmentStatus = z.enum(["agendado", "confirmado", "andamento", "concluido", "cancelado", "faltou"]);
const paymentStatus = z.enum(["pendente", "parcial", "pago"]);

async function requireProfile(userId: number) {
  const profile = await getProfileByUserId(userId);
  if (!profile) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Finalize seu perfil para continuar." });
  return profile;
}

async function getOwnedService(profileId: number, serviceId: number) {
  const db = await getDb();
  if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Banco de dados indisponível." });
  const result = await db.select().from(services).where(and(eq(services.id, serviceId), eq(services.profileId, profileId))).limit(1);
  if (!result[0]) throw new TRPCError({ code: "NOT_FOUND", message: "Serviço não encontrado." });
  return result[0];
}

async function getOwnedClient(profileId: number, clientId: number) {
  const db = await getDb();
  if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Banco de dados indisponível." });
  const result = await db.select().from(clients).where(and(eq(clients.id, clientId), eq(clients.profileId, profileId))).limit(1);
  if (!result[0]) throw new TRPCError({ code: "NOT_FOUND", message: "Cliente não encontrado." });
  return result[0];
}

function dayStart(date = new Date()) {
  const start = new Date(date);
  start.setHours(0, 0, 0, 0);
  return start;
}

function dayEnd(date = new Date()) {
  const end = dayStart(date);
  end.setDate(end.getDate() + 1);
  return end;
}

export function isWithinAvailability(start: Date, durationMinutes: number, availabilityRow: { schedule: string; unavailableDays: string | null } | undefined) {
  if (!availabilityRow) return true;
  try {
    const config = JSON.parse(availabilityRow.schedule) as {
      days?: string[];
      start?: string;
      end?: string;
      breaks?: Array<{ start: string; end: string }>;
    };
    const dayNames = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
    const day = dayNames[start.getDay()];
    if (config.days?.length && !config.days.includes(day)) return false;
    const toMinutes = (value: string) => {
      const [hours, minutes] = value.split(":").map(Number);
      return hours * 60 + minutes;
    };
    const startMinutes = start.getHours() * 60 + start.getMinutes();
    const endMinutes = startMinutes + durationMinutes;
    if (config.start && startMinutes < toMinutes(config.start)) return false;
    if (config.end && endMinutes > toMinutes(config.end)) return false;
    if (config.breaks?.some(item => startMinutes < toMinutes(item.end) && endMinutes > toMinutes(item.start))) return false;
    const unavailable = availabilityRow.unavailableDays ? JSON.parse(availabilityRow.unavailableDays) as string[] : [];
    const dateKey = `${start.getFullYear()}-${String(start.getMonth() + 1).padStart(2, "0")}-${String(start.getDate()).padStart(2, "0")}`;
    return !unavailable.includes(dateKey);
  } catch {
    return true;
  }
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  profile: router({
    get: protectedProcedure.query(({ ctx }) => getProfileByUserId(ctx.user.id)),
    upsert: protectedProcedure
      .input(z.object({
        displayName: z.string().min(2).max(160),
        slug: z.string().min(3).max(100).regex(/^[a-z0-9-]+$/, "Use apenas letras minúsculas, números e hífen."),
        professionCategory: z.string().max(100).optional(),
        professionName: z.string().min(2).max(160),
        bio: z.string().max(1200).optional(),
        city: z.string().max(120).optional(),
        serviceRegion: z.string().max(160).optional(),
        phone: z.string().max(40).optional(),
        whatsapp: z.string().max(40).optional(),
        avatarUrl: z.string().max(500).optional(),
        showPrices: z.boolean().default(true),
        bookingEnabled: z.boolean().default(false),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Banco de dados indisponível." });
        const current = await getProfileByUserId(ctx.user.id);
        try {
          if (current) {
            await db.update(professionalProfiles).set({ ...input, professionCategory: input.professionCategory ?? null, bio: input.bio ?? null, city: input.city ?? null, serviceRegion: input.serviceRegion ?? null, phone: input.phone ?? null, whatsapp: input.whatsapp ?? null }).where(eq(professionalProfiles.id, current.id));
          } else {
            const slugOwner = await getProfileBySlug(input.slug);
            const slug = slugOwner && slugOwner.userId !== ctx.user.id
              ? `${input.slug}-${nanoid(6).toLowerCase()}`.slice(0, 100)
              : input.slug;
            await db.insert(professionalProfiles).values({ ...input, slug, userId: ctx.user.id, professionCategory: input.professionCategory ?? null, bio: input.bio ?? null, city: input.city ?? null, serviceRegion: input.serviceRegion ?? null, phone: input.phone ?? null, whatsapp: input.whatsapp ?? null });
          }
        } catch {
          throw new TRPCError({ code: "CONFLICT", message: "Esse endereço público já está em uso." });
        }
        return getProfileByUserId(ctx.user.id);
      }),
    saveAvailability: protectedProcedure
      .input(z.object({ schedule: z.string().min(2), unavailableDays: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        const profile = await requireProfile(ctx.user.id);
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const existing = await db.select().from(availability).where(eq(availability.profileId, profile.id)).limit(1);
        if (existing[0]) await db.update(availability).set({ schedule: input.schedule, unavailableDays: input.unavailableDays ?? null }).where(eq(availability.profileId, profile.id));
        else await db.insert(availability).values({ profileId: profile.id, schedule: input.schedule, unavailableDays: input.unavailableDays ?? null });
        return { success: true };
      }),
    getAvailability: protectedProcedure.query(async ({ ctx }) => {
      const profile = await requireProfile(ctx.user.id);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const result = await db.select().from(availability).where(eq(availability.profileId, profile.id)).limit(1);
      return result[0] ?? null;
    }),
    uploadAvatar: protectedProcedure.input(z.object({ fileName: z.string().max(180), mimeType: z.enum(["image/jpeg", "image/png", "image/webp"]), dataUrl: z.string().max(7_000_000) })).mutation(async ({ ctx, input }) => {
      const profile = await requireProfile(ctx.user.id);
      const encoded = input.dataUrl.split(",")[1];
      if (!encoded) throw new TRPCError({ code: "BAD_REQUEST", message: "Arquivo inválido." });
      const buffer = Buffer.from(encoded, "base64");
      if (buffer.length > 5_000_000) throw new TRPCError({ code: "BAD_REQUEST", message: "A foto deve ter no máximo 5 MB." });
      const stored = await storagePut(`profiles/${profile.id}/avatar-${input.fileName}`, buffer, input.mimeType);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await db.update(professionalProfiles).set({ avatarUrl: stored.url }).where(eq(professionalProfiles.id, profile.id));
      return { success: true, avatarUrl: stored.url };
    }),
  }),

  service: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const profile = await requireProfile(ctx.user.id);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      return db.select().from(services).where(eq(services.profileId, profile.id)).orderBy(desc(services.active), desc(services.createdAt));
    }),
    create: protectedProcedure.input(z.object({ name: z.string().min(2).max(160), description: z.string().max(1000).optional(), durationMinutes: z.number().int().min(15).max(1440), priceCents: z.number().int().min(0), modality })).mutation(async ({ ctx, input }) => {
      const profile = await requireProfile(ctx.user.id);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await db.insert(services).values({ ...input, profileId: profile.id, description: input.description ?? null });
      return { success: true };
    }),
    update: protectedProcedure.input(z.object({ id: z.number(), name: z.string().min(2).max(160), description: z.string().max(1000).optional(), durationMinutes: z.number().int().min(15).max(1440), priceCents: z.number().int().min(0), modality, active: z.boolean() })).mutation(async ({ ctx, input }) => {
      const profile = await requireProfile(ctx.user.id);
      await getOwnedService(profile.id, input.id);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await db.update(services).set({ name: input.name, description: input.description ?? null, durationMinutes: input.durationMinutes, priceCents: input.priceCents, modality: input.modality, active: input.active }).where(eq(services.id, input.id));
      return { success: true };
    }),
    remove: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ ctx, input }) => {
      const profile = await requireProfile(ctx.user.id);
      await getOwnedService(profile.id, input.id);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await db.update(services).set({ active: false }).where(eq(services.id, input.id));
      return { success: true };
    }),
  }),

  customer: router({
    list: protectedProcedure.input(z.object({ includeArchived: z.boolean().default(false) }).optional()).query(async ({ ctx, input }) => {
      const profile = await requireProfile(ctx.user.id);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const conditions = input?.includeArchived ? eq(clients.profileId, profile.id) : and(eq(clients.profileId, profile.id), eq(clients.archived, false));
      return db.select().from(clients).where(conditions).orderBy(desc(clients.createdAt));
    }),
    create: protectedProcedure.input(z.object({ name: z.string().min(2).max(160), phone: z.string().max(40).optional(), whatsapp: z.string().max(40).optional(), email: z.string().email().optional().or(z.literal("")), address: z.string().max(600).optional(), notes: z.string().max(1200).optional() })).mutation(async ({ ctx, input }) => {
      const profile = await requireProfile(ctx.user.id);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await db.insert(clients).values({ ...input, profileId: profile.id, phone: input.phone ?? null, whatsapp: input.whatsapp ?? null, email: input.email || null, address: input.address ?? null, notes: input.notes ?? null });
      return { success: true };
    }),
    update: protectedProcedure.input(z.object({ id: z.number(), name: z.string().min(2).max(160), phone: z.string().max(40).optional(), whatsapp: z.string().max(40).optional(), email: z.string().email().optional().or(z.literal("")), address: z.string().max(600).optional(), notes: z.string().max(1200).optional(), archived: z.boolean().default(false) })).mutation(async ({ ctx, input }) => {
      const profile = await requireProfile(ctx.user.id);
      await getOwnedClient(profile.id, input.id);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await db.update(clients).set({ name: input.name, phone: input.phone ?? null, whatsapp: input.whatsapp ?? null, email: input.email || null, address: input.address ?? null, notes: input.notes ?? null, archived: input.archived }).where(eq(clients.id, input.id));
      return { success: true };
    }),
    history: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ ctx, input }) => {
      const profile = await requireProfile(ctx.user.id);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const client = await getOwnedClient(profile.id, input.id);
      const [clientAppointments, clientQuotes, clientPayments] = await Promise.all([
        db.select().from(appointments).where(and(eq(appointments.profileId, profile.id), eq(appointments.clientId, input.id))).orderBy(desc(appointments.startsAt)),
        db.select().from(quotes).where(and(eq(quotes.profileId, profile.id), eq(quotes.clientId, input.id))).orderBy(desc(quotes.createdAt)),
        db.select().from(payments).where(and(eq(payments.profileId, profile.id), eq(payments.clientId, input.id))).orderBy(desc(payments.createdAt)),
      ]);
      return { client, appointments: clientAppointments, quotes: clientQuotes, payments: clientPayments };
    }),
    remove: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ ctx, input }) => {
      const profile = await requireProfile(ctx.user.id);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await getOwnedClient(profile.id, input.id);
      const related = await db.select({ id: appointments.id }).from(appointments).where(and(eq(appointments.profileId, profile.id), eq(appointments.clientId, input.id))).limit(1);
      if (related[0]) {
        await db.update(clients).set({ archived: true }).where(eq(clients.id, input.id));
      } else {
        await db.delete(clients).where(and(eq(clients.id, input.id), eq(clients.profileId, profile.id)));
      }
      return { success: true };
    }),
  }),

  appointment: router({
    list: protectedProcedure.input(z.object({ from: z.string().datetime().optional(), to: z.string().datetime().optional() }).optional()).query(async ({ ctx, input }) => {
      const profile = await requireProfile(ctx.user.id);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const conditions = [eq(appointments.profileId, profile.id)];
      if (input?.from) conditions.push(gte(appointments.startsAt, new Date(input.from)));
      if (input?.to) conditions.push(lt(appointments.startsAt, new Date(input.to)));
      return db.select().from(appointments).where(and(...conditions)).orderBy(appointments.startsAt);
    }),
    create: protectedProcedure.input(z.object({ clientId: z.number().optional(), serviceId: z.number().optional(), startsAt: z.string().datetime(), durationMinutes: z.number().int().min(15).max(1440), location: z.string().max(600).optional(), amountCents: z.number().int().min(0), status: appointmentStatus.default("agendado"), notes: z.string().max(1200).optional(), paymentMethod: paymentMethod.optional(), paymentStatus: paymentStatus.default("pendente") })).mutation(async ({ ctx, input }) => {
      const profile = await requireProfile(ctx.user.id);
      if (input.clientId) await getOwnedClient(profile.id, input.clientId);
      if (input.serviceId) await getOwnedService(profile.id, input.serviceId);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const start = new Date(input.startsAt);
      const availabilityRow = (await db.select().from(availability).where(eq(availability.profileId, profile.id)).limit(1))[0];
      if (!isWithinAvailability(start, input.durationMinutes, availabilityRow)) {
        throw new TRPCError({ code: "CONFLICT", message: "Esse horário está fora da sua disponibilidade." });
      }
      const end = new Date(start.getTime() + input.durationMinutes * 60_000);
      const sameDay = await db.select().from(appointments).where(and(eq(appointments.profileId, profile.id), gte(appointments.startsAt, dayStart(start)), lt(appointments.startsAt, dayEnd(start)), ne(appointments.status, "cancelado")));
      const conflict = sameDay.some(item => {
        const itemStart = new Date(item.startsAt).getTime();
        const itemEnd = itemStart + item.durationMinutes * 60_000;
        return itemStart < end.getTime() && start.getTime() < itemEnd;
      });
      if (conflict) throw new TRPCError({ code: "CONFLICT", message: "Esse horário já está ocupado." });
      await db.insert(appointments).values({ ...input, profileId: profile.id, startsAt: start, clientId: input.clientId ?? null, serviceId: input.serviceId ?? null, location: input.location ?? null, notes: input.notes ?? null, paymentMethod: input.paymentMethod ?? null });
      return { success: true };
    }),
    updateStatus: protectedProcedure.input(z.object({ id: z.number(), status: appointmentStatus, paymentStatus: paymentStatus.optional(), paymentMethod: paymentMethod.optional() })).mutation(async ({ ctx, input }) => {
      const profile = await requireProfile(ctx.user.id);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const result = await db.select().from(appointments).where(and(eq(appointments.id, input.id), eq(appointments.profileId, profile.id))).limit(1);
      if (!result[0]) throw new TRPCError({ code: "NOT_FOUND" });
      await db.update(appointments).set({ status: input.status, paymentStatus: input.paymentStatus ?? result[0].paymentStatus, paymentMethod: input.paymentMethod ?? result[0].paymentMethod }).where(eq(appointments.id, input.id));
      return { success: true };
    }),
    update: protectedProcedure.input(z.object({ id: z.number(), clientId: z.number().optional(), serviceId: z.number().optional(), startsAt: z.string().datetime(), durationMinutes: z.number().int().min(15).max(1440), location: z.string().max(600).optional(), amountCents: z.number().int().min(0), notes: z.string().max(1200).optional() })).mutation(async ({ ctx, input }) => {
      const profile = await requireProfile(ctx.user.id);
      if (input.clientId) await getOwnedClient(profile.id, input.clientId);
      if (input.serviceId) await getOwnedService(profile.id, input.serviceId);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const existing = (await db.select().from(appointments).where(and(eq(appointments.id, input.id), eq(appointments.profileId, profile.id))).limit(1))[0];
      if (!existing) throw new TRPCError({ code: "NOT_FOUND", message: "Atendimento não encontrado." });
      const start = new Date(input.startsAt);
      const availabilityRow = (await db.select().from(availability).where(eq(availability.profileId, profile.id)).limit(1))[0];
      if (!isWithinAvailability(start, input.durationMinutes, availabilityRow)) throw new TRPCError({ code: "CONFLICT", message: "Esse horário está fora da sua disponibilidade." });
      const end = new Date(start.getTime() + input.durationMinutes * 60_000).getTime();
      const sameDay = await db.select().from(appointments).where(and(eq(appointments.profileId, profile.id), gte(appointments.startsAt, dayStart(start)), lt(appointments.startsAt, dayEnd(start)), ne(appointments.status, "cancelado"), ne(appointments.id, input.id)));
      if (sameDay.some(item => new Date(item.startsAt).getTime() < end && start.getTime() < new Date(item.startsAt).getTime() + item.durationMinutes * 60_000)) throw new TRPCError({ code: "CONFLICT", message: "Esse horário já está ocupado." });
      await db.update(appointments).set({ clientId: input.clientId ?? null, serviceId: input.serviceId ?? null, startsAt: start, durationMinutes: input.durationMinutes, location: input.location ?? null, amountCents: input.amountCents, notes: input.notes ?? null }).where(eq(appointments.id, input.id));
      return { success: true };
    }),
    cancel: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ ctx, input }) => {
      const profile = await requireProfile(ctx.user.id);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await db.update(appointments).set({ status: "cancelado" }).where(and(eq(appointments.id, input.id), eq(appointments.profileId, profile.id)));
      return { success: true };
    }),
  }),

  request: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const profile = await requireProfile(ctx.user.id);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const rows = await db.select().from(requests).where(eq(requests.profileId, profile.id)).orderBy(desc(requests.createdAt));
      return Promise.all(rows.map(async request => ({ ...request, attachments: await db.select().from(requestAttachments).where(eq(requestAttachments.requestId, request.id)) })));
    }),
    createPublic: publicProcedure.input(z.object({ slug: z.string(), requesterName: z.string().min(2).max(160), requesterPhone: z.string().min(8).max(40), requesterEmail: z.string().email().optional().or(z.literal("")), serviceId: z.number().optional(), description: z.string().min(10).max(3000), address: z.string().max(600).optional(), desiredAt: z.string().datetime().optional(), preferredTime: z.string().max(80).optional(), attachments: z.array(z.object({ name: z.string().max(180), mimeType: z.enum(["image/jpeg", "image/png", "image/webp", "application/pdf"]), size: z.number().int().positive().max(5_000_000), dataUrl: z.string().max(7_000_000) })).max(3).optional() })).mutation(async ({ input }) => {
      const profile = await getProfileBySlug(input.slug);
      if (!profile) throw new TRPCError({ code: "NOT_FOUND", message: "Profissional não encontrado." });
      if (input.serviceId) await getOwnedService(profile.id, input.serviceId);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const existingClient = await db.select().from(clients).where(and(eq(clients.profileId, profile.id), eq(clients.phone, input.requesterPhone))).limit(1);
      let clientId = existingClient[0]?.id;
      if (!clientId) {
        const insert = (await db.insert(clients).values({ profileId: profile.id, name: input.requesterName, phone: input.requesterPhone, email: input.requesterEmail || null })) as unknown as [{ insertId: number }];
        clientId = Number(insert[0].insertId);
      }
      const secureToken = nanoid(32);
      const insert = (await db.insert(requests).values({ profileId: profile.id, clientId, requesterName: input.requesterName, requesterPhone: input.requesterPhone, requesterEmail: input.requesterEmail || null, serviceId: input.serviceId ?? null, description: input.description, address: input.address ?? null, desiredAt: input.desiredAt ? new Date(input.desiredAt) : null, preferredTime: input.preferredTime ?? null, secureToken })) as unknown as [{ insertId: number }];
      const requestId = Number(insert[0].insertId);
      for (const attachment of input.attachments ?? []) {
        const encoded = attachment.dataUrl.split(",")[1];
        if (!encoded) continue;
        const buffer = Buffer.from(encoded, "base64");
        if (buffer.length > 5_000_000) throw new TRPCError({ code: "BAD_REQUEST", message: "Cada anexo deve ter no máximo 5 MB." });
        const stored = await storagePut(`requests/${profile.id}/${requestId}/${attachment.name}`, buffer, attachment.mimeType);
        await db.insert(requestAttachments).values({ requestId, fileName: attachment.name, fileUrl: stored.url, mimeType: attachment.mimeType, fileSize: buffer.length });
      }
      await createNotification(profile.id, "Nova solicitação", `${input.requesterName} enviou um pedido de serviço.`, "request");
      return { success: true, id: requestId, token: secureToken };
    }),
    updateStatus: protectedProcedure.input(z.object({ id: z.number(), status: z.enum(["nova", "em_analise", "orcamento_enviado", "agendada", "arquivada"]) })).mutation(async ({ ctx, input }) => {
      const profile = await requireProfile(ctx.user.id);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await db.update(requests).set({ status: input.status }).where(and(eq(requests.id, input.id), eq(requests.profileId, profile.id)));
      return { success: true };
    }),
    convertToClient: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ ctx, input }) => {
      const profile = await requireProfile(ctx.user.id);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const request = (await db.select().from(requests).where(and(eq(requests.id, input.id), eq(requests.profileId, profile.id))).limit(1))[0];
      if (!request) throw new TRPCError({ code: "NOT_FOUND", message: "Solicitação não encontrada." });
      if (request.clientId) return { success: true, clientId: request.clientId };
      const inserted = (await db.insert(clients).values({ profileId: profile.id, name: request.requesterName, phone: request.requesterPhone, email: request.requesterEmail, address: request.address })) as unknown as [{ insertId: number }];
      const clientId = Number(inserted[0].insertId);
      await db.update(requests).set({ clientId }).where(eq(requests.id, request.id));
      return { success: true, clientId };
    }),
    convertToAppointment: protectedProcedure.input(z.object({ id: z.number(), startsAt: z.string().datetime().optional() })).mutation(async ({ ctx, input }) => {
      const profile = await requireProfile(ctx.user.id);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const request = (await db.select().from(requests).where(and(eq(requests.id, input.id), eq(requests.profileId, profile.id))).limit(1))[0];
      if (!request) throw new TRPCError({ code: "NOT_FOUND", message: "Solicitação não encontrada." });
      if (!request.clientId) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Converta a solicitação em cliente antes de agendar." });
      if (!input.startsAt && !request.desiredAt) throw new TRPCError({ code: "BAD_REQUEST", message: "Informe uma data para o atendimento." });
      const service = request.serviceId ? await getOwnedService(profile.id, request.serviceId) : undefined;
      const start = new Date(input.startsAt ?? request.desiredAt!);
      const durationMinutes = service?.durationMinutes ?? 60;
      const availabilityRow = (await db.select().from(availability).where(eq(availability.profileId, profile.id)).limit(1))[0];
      if (!isWithinAvailability(start, durationMinutes, availabilityRow)) throw new TRPCError({ code: "CONFLICT", message: "Esse horário está fora da sua disponibilidade." });
      const conflictRows = await db.select().from(appointments).where(and(eq(appointments.profileId, profile.id), gte(appointments.startsAt, dayStart(start)), lt(appointments.startsAt, dayEnd(start)), ne(appointments.status, "cancelado")));
      if (conflictRows.some(item => new Date(item.startsAt).getTime() < start.getTime() + durationMinutes * 60_000 && start.getTime() < new Date(item.startsAt).getTime() + item.durationMinutes * 60_000)) throw new TRPCError({ code: "CONFLICT", message: "Esse horário já está ocupado." });
      const inserted = (await db.insert(appointments).values({ profileId: profile.id, clientId: request.clientId, serviceId: request.serviceId, startsAt: start, durationMinutes, location: request.address, amountCents: service?.priceCents ?? 0, notes: request.description, status: "agendado", paymentStatus: "pendente" })) as unknown as [{ insertId: number }];
      await db.update(requests).set({ status: "agendada" }).where(eq(requests.id, request.id));
      return { success: true, appointmentId: Number(inserted[0].insertId) };
    }),
    convertToQuote: protectedProcedure.input(z.object({ id: z.number(), discountCents: z.number().int().min(0).default(0), sendNow: z.boolean().default(true) })).mutation(async ({ ctx, input }) => {
      const profile = await requireProfile(ctx.user.id);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const request = (await db.select().from(requests).where(and(eq(requests.id, input.id), eq(requests.profileId, profile.id))).limit(1))[0];
      if (!request) throw new TRPCError({ code: "NOT_FOUND", message: "Solicitação não encontrada." });
      const service = request.serviceId ? await getOwnedService(profile.id, request.serviceId) : undefined;
      const item = { description: service?.name || "Serviço solicitado", quantity: 1, unitPriceCents: service?.priceCents || 0 };
      const secureToken = nanoid(32);
      const insert = (await db.insert(quotes).values({ profileId: profile.id, clientId: request.clientId ?? null, requestId: request.id, serviceId: request.serviceId ?? null, description: request.description, subtotalCents: item.unitPriceCents, discountCents: input.discountCents, totalCents: Math.max(0, item.unitPriceCents - input.discountCents), notes: request.address ? `Endereço: ${request.address}` : null, validUntil: null, secureToken, status: input.sendNow ? "enviado" : "rascunho" })) as unknown as [{ insertId: number }];
      await db.insert(quoteItems).values({ quoteId: Number(insert[0].insertId), ...item, totalCents: item.unitPriceCents });
      await db.update(requests).set({ status: input.sendNow ? "orcamento_enviado" : "em_analise" }).where(eq(requests.id, request.id));
      return { success: true, quoteId: Number(insert[0].insertId), token: secureToken };
    }),
  }),

  quote: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const profile = await requireProfile(ctx.user.id);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      return db.select().from(quotes).where(eq(quotes.profileId, profile.id)).orderBy(desc(quotes.createdAt));
    }),
    create: protectedProcedure.input(z.object({ clientId: z.number().optional(), requestId: z.number().optional(), serviceId: z.number().optional(), description: z.string().max(1800).optional(), discountCents: z.number().int().min(0).default(0), notes: z.string().max(1800).optional(), validUntil: z.string().datetime().optional(), sendNow: z.boolean().default(false), items: z.array(z.object({ description: z.string().min(1).max(180), quantity: z.number().int().min(1).max(100), unitPriceCents: z.number().int().min(0) })).min(1) })).mutation(async ({ ctx, input }) => {
      const profile = await requireProfile(ctx.user.id);
      if (input.clientId) await getOwnedClient(profile.id, input.clientId);
      if (input.serviceId) await getOwnedService(profile.id, input.serviceId);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const subtotalCents = input.items.reduce((sum, item) => sum + item.quantity * item.unitPriceCents, 0);
      const totalCents = Math.max(0, subtotalCents - input.discountCents);
      const secureToken = nanoid(32);
      const insert = (await db.insert(quotes).values({ profileId: profile.id, clientId: input.clientId ?? null, requestId: input.requestId ?? null, serviceId: input.serviceId ?? null, description: input.description ?? null, subtotalCents, discountCents: input.discountCents, totalCents, notes: input.notes ?? null, validUntil: input.validUntil ? new Date(input.validUntil) : null, secureToken, status: input.sendNow ? "enviado" : "rascunho" })) as unknown as [{ insertId: number }];
      const quoteId = Number(insert[0].insertId);
      await db.insert(quoteItems).values(input.items.map(item => ({ quoteId, description: item.description, quantity: item.quantity, unitPriceCents: item.unitPriceCents, totalCents: item.quantity * item.unitPriceCents })));
      if (input.requestId) await db.update(requests).set({ status: input.sendNow ? "orcamento_enviado" : "em_analise" }).where(and(eq(requests.id, input.requestId), eq(requests.profileId, profile.id)));
      if (input.sendNow) await createNotification(profile.id, "Orçamento enviado", "Seu orçamento está disponível por um link público.", "quote");
      return { success: true, quoteId, token: secureToken };
    }),
    getPublic: publicProcedure.input(z.object({ token: z.string().min(10) })).query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const quote = (await db.select().from(quotes).where(eq(quotes.secureToken, input.token)).limit(1))[0];
      if (!quote) throw new TRPCError({ code: "NOT_FOUND", message: "Orçamento não encontrado." });
      const profile = (await db.select().from(professionalProfiles).where(eq(professionalProfiles.id, quote.profileId)).limit(1))[0];
      const items = await db.select().from(quoteItems).where(eq(quoteItems.quoteId, quote.id));
      return { quote, profile, items };
    }),
    respondPublic: publicProcedure.input(z.object({ token: z.string().min(10), action: z.enum(["aceito", "recusado", "alteracao_solicitada"]) })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const quote = (await db.select().from(quotes).where(eq(quotes.secureToken, input.token)).limit(1))[0];
      if (!quote) throw new TRPCError({ code: "NOT_FOUND", message: "Orçamento não encontrado." });
      await db.update(quotes).set({ status: input.action, respondedAt: new Date() }).where(eq(quotes.id, quote.id));
      await createNotification(quote.profileId, "Orçamento respondido", `O cliente respondeu: ${input.action === "aceito" ? "aceito" : input.action === "recusado" ? "recusado" : "solicitou alteração"}.`, "quote_response");
      return { success: true };
    }),
  }),

  payment: router({
    list: protectedProcedure.input(z.object({ from: z.string().datetime().optional(), to: z.string().datetime().optional() }).optional()).query(async ({ ctx, input }) => {
      const profile = await requireProfile(ctx.user.id);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const conditions = [eq(payments.profileId, profile.id)];
      if (input?.from) conditions.push(gte(payments.createdAt, new Date(input.from)));
      if (input?.to) conditions.push(lt(payments.createdAt, new Date(input.to)));
      return db.select().from(payments).where(and(...conditions)).orderBy(desc(payments.createdAt));
    }),
    create: protectedProcedure.input(z.object({ appointmentId: z.number().optional(), clientId: z.number().optional(), serviceId: z.number().optional(), amountCents: z.number().int().positive(), method: paymentMethod, status: paymentStatus, note: z.string().max(600).optional(), paidAt: z.string().datetime().optional() })).mutation(async ({ ctx, input }) => {
      const profile = await requireProfile(ctx.user.id);
      if (input.clientId) await getOwnedClient(profile.id, input.clientId);
      if (input.serviceId) await getOwnedService(profile.id, input.serviceId);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await db.insert(payments).values({ ...input, profileId: profile.id, appointmentId: input.appointmentId ?? null, clientId: input.clientId ?? null, serviceId: input.serviceId ?? null, note: input.note ?? null, paidAt: input.paidAt ? new Date(input.paidAt) : input.status === "pago" ? new Date() : null });
      if (input.appointmentId) await db.update(appointments).set({ paymentStatus: input.status }).where(and(eq(appointments.id, input.appointmentId), eq(appointments.profileId, profile.id)));
      return { success: true };
    }),
  }),

  expense: router({
    list: protectedProcedure.input(z.object({ from: z.string().datetime().optional(), to: z.string().datetime().optional() }).optional()).query(async ({ ctx, input }) => {
      const profile = await requireProfile(ctx.user.id);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const conditions = [eq(expenses.profileId, profile.id)];
      if (input?.from) conditions.push(gte(expenses.occurredAt, new Date(input.from)));
      if (input?.to) conditions.push(lt(expenses.occurredAt, new Date(input.to)));
      return db.select().from(expenses).where(and(...conditions)).orderBy(desc(expenses.occurredAt));
    }),
    create: protectedProcedure.input(z.object({ description: z.string().min(2).max(180), category: z.string().max(100).optional(), amountCents: z.number().int().positive(), occurredAt: z.string().datetime().optional(), note: z.string().max(600).optional() })).mutation(async ({ ctx, input }) => {
      const profile = await requireProfile(ctx.user.id);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await db.insert(expenses).values({ profileId: profile.id, description: input.description, category: input.category ?? null, amountCents: input.amountCents, occurredAt: input.occurredAt ? new Date(input.occurredAt) : new Date(), note: input.note ?? null });
      return { success: true };
    }),
    remove: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ ctx, input }) => {
      const profile = await requireProfile(ctx.user.id);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await db.delete(expenses).where(and(eq(expenses.id, input.id), eq(expenses.profileId, profile.id)));
      return { success: true };
    }),
  }),

  notification: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const profile = await requireProfile(ctx.user.id);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      return db.select().from(notifications).where(eq(notifications.profileId, profile.id)).orderBy(desc(notifications.createdAt)).limit(30);
    }),
    markRead: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ ctx, input }) => {
      const profile = await requireProfile(ctx.user.id);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await db.update(notifications).set({ read: true }).where(and(eq(notifications.id, input.id), eq(notifications.profileId, profile.id)));
      return { success: true };
    }),
    unreadCount: protectedProcedure.query(async ({ ctx }) => {
      const profile = await requireProfile(ctx.user.id);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const rows = await db.select({ id: notifications.id }).from(notifications).where(and(eq(notifications.profileId, profile.id), eq(notifications.read, false)));
      return rows.length;
    }),
  }),

  reports: router({
    summary: protectedProcedure.input(z.object({ from: z.string().datetime().optional(), to: z.string().datetime().optional() }).optional()).query(async ({ ctx, input }) => {
      const profile = await requireProfile(ctx.user.id);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const now = new Date();
      const defaultFrom = new Date(now.getFullYear(), now.getMonth(), 1);
      const from = input?.from ? new Date(input.from) : defaultFrom;
      const to = input?.to ? new Date(input.to) : new Date(now.getTime() + 1);
      const [periodAppointments, periodPayments, periodClients, profileServices] = await Promise.all([
        db.select().from(appointments).where(and(eq(appointments.profileId, profile.id), gte(appointments.startsAt, from), lt(appointments.startsAt, to), ne(appointments.status, "cancelado"))),
        db.select().from(payments).where(and(eq(payments.profileId, profile.id), gte(payments.createdAt, from), lt(payments.createdAt, to))),
        db.select().from(clients).where(and(eq(clients.profileId, profile.id), gte(clients.createdAt, from), lt(clients.createdAt, to))),
        db.select().from(services).where(eq(services.profileId, profile.id)),
      ]);
      const receivedCents = periodPayments.filter(item => item.status === "pago").reduce((sum, item) => sum + item.amountCents, 0);
      const pendingCents = periodPayments.filter(item => item.status !== "pago").reduce((sum, item) => sum + item.amountCents, 0);
      const counts = new Map<number, number>();
      for (const item of periodAppointments) if (item.serviceId) counts.set(item.serviceId, (counts.get(item.serviceId) || 0) + 1);
      const topServices = Array.from(counts.entries()).map(([serviceId, count]) => ({ serviceId, count, name: profileServices.find(service => service.id === serviceId)?.name || "Serviço" })).sort((a, b) => b.count - a.count).slice(0, 5);
      const allClientAppointments = await db.select({ clientId: appointments.clientId }).from(appointments).where(and(eq(appointments.profileId, profile.id), ne(appointments.status, "cancelado")));
      const clientVisitCounts = new Map<number, number>();
      for (const item of allClientAppointments) if (item.clientId) clientVisitCounts.set(item.clientId, (clientVisitCounts.get(item.clientId) || 0) + 1);
      const recurringClientIds = Array.from(clientVisitCounts.values()).filter(count => count > 1).length;
      return { from, to, revenueCents: receivedCents + pendingCents, receivedCents, pendingCents, appointmentCount: periodAppointments.length, newClients: periodClients.length, recurringClients: recurringClientIds, topServices };
    }),
  }),

  dashboard: router({
    summary: protectedProcedure.input(z.object({ from: z.string().datetime().optional(), to: z.string().datetime().optional() }).optional()).query(async ({ ctx, input }) => {
      const profile = await requireProfile(ctx.user.id);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const today = await db.select().from(appointments).where(and(eq(appointments.profileId, profile.id), gte(appointments.startsAt, dayStart()), lt(appointments.startsAt, dayEnd()))).orderBy(appointments.startsAt);
      const recentRequests = await db.select().from(requests).where(and(eq(requests.profileId, profile.id), ne(requests.status, "arquivada"))).orderBy(desc(requests.createdAt)).limit(4);
      const pendingQuotes = await db.select().from(quotes).where(and(eq(quotes.profileId, profile.id), eq(quotes.status, "enviado"))).orderBy(desc(quotes.createdAt)).limit(4);
      const monthStart = new Date(); monthStart.setDate(1); monthStart.setHours(0, 0, 0, 0);
      const periodFrom = input?.from ? new Date(input.from) : monthStart;
      const periodTo = input?.to ? new Date(input.to) : new Date();
      const monthPayments = await db.select().from(payments).where(and(eq(payments.profileId, profile.id), gte(payments.createdAt, periodFrom), lt(payments.createdAt, periodTo)));
      const monthExpenses = await db.select().from(expenses).where(and(eq(expenses.profileId, profile.id), gte(expenses.occurredAt, periodFrom), lt(expenses.occurredAt, periodTo)));
      const received = monthPayments.filter(p => p.status === "pago").reduce((sum, p) => sum + p.amountCents, 0);
      const pending = monthPayments.filter(p => p.status !== "pago").reduce((sum, p) => sum + p.amountCents, 0);
      const expensesCents = monthExpenses.reduce((sum, item) => sum + item.amountCents, 0);
      const projected = today.reduce((sum, item) => sum + item.amountCents, 0);
      const seriesMap = new Map<string, { date: string; receitas: number; pendentes: number; despesas: number }>();
      const ensureDay = (date: Date) => { const key = date.toISOString().slice(0, 10); if (!seriesMap.has(key)) seriesMap.set(key, { date: key, receitas: 0, pendentes: 0, despesas: 0 }); return seriesMap.get(key)!; };
      for (const payment of monthPayments) { const day = ensureDay(new Date(payment.createdAt)); if (payment.status === "pago") day.receitas += payment.amountCents; else day.pendentes += payment.amountCents; }
      for (const expense of monthExpenses) { const day = ensureDay(new Date(expense.occurredAt)); day.despesas += expense.amountCents; }
      const monthlySeries = Array.from(seriesMap.values()).sort((a, b) => a.date.localeCompare(b.date)).map((day, index, rows) => ({ ...day, saldo: rows.slice(0, index + 1).reduce((sum, item) => sum + item.receitas - item.despesas, 0) }));
      return { profile, today, recentRequests, pendingQuotes, monthlySeries, metrics: { todayCount: today.filter(a => a.status !== "cancelado").length, todayProjectedCents: projected, receivedCents: received, pendingCents: pending, monthRevenueCents: received + pending, expensesCents, balanceCents: received - expensesCents } };
    }),
  }),

  publicProfile: router({
    bySlug: publicProcedure.input(z.object({ slug: z.string() })).query(async ({ input }) => {
      const profile = await getProfileBySlug(input.slug);
      if (!profile) throw new TRPCError({ code: "NOT_FOUND", message: "Profissional não encontrado." });
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const profileServices = await db.select().from(services).where(and(eq(services.profileId, profile.id), eq(services.active, true))).orderBy(services.name);
      return { profile, services: profileServices };
    }),
  }),
});

export type AppRouter = typeof appRouter;
