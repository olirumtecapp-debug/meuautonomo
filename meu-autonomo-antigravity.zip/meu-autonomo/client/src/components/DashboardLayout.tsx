import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { useTheme } from "@/contexts/ThemeContext";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
  useSidebar,
} from "@/components/ui/sidebar";
import { useIsMobile } from "@/hooks/useMobile";
import {
  Archive,
  BarChart3,
  BriefcaseBusiness,
  CalendarDays,
  CircleDollarSign,
  ClipboardList,
  LayoutDashboard,
  LogOut,
  Menu,
  Bell,
  Monitor,
  Moon,
  PanelLeft,
  Settings,
  Sparkles,
  UserRound,
  SunMedium,
  Users,
} from "lucide-react";
import { CSSProperties, useEffect, useRef, useState } from "react";
import { Link, useLocation } from "wouter";
import { DashboardLayoutSkeleton } from "./DashboardLayoutSkeleton";
import { Button } from "./ui/button";

const menuItems = [
  { icon: LayoutDashboard, label: "Visão geral", path: "/app" },
  { icon: SunMedium, label: "Meu Dia", path: "/meu-dia" },
  { icon: CalendarDays, label: "Agenda", path: "/agenda" },
  { icon: Users, label: "Clientes", path: "/clientes" },
  { icon: BriefcaseBusiness, label: "Serviços", path: "/servicos" },
  { icon: ClipboardList, label: "Solicitações", path: "/solicitacoes" },
  { icon: Archive, label: "Orçamentos", path: "/orcamentos" },
  { icon: CircleDollarSign, label: "Financeiro", path: "/financeiro" },
  { icon: BarChart3, label: "Relatórios", path: "/relatorios" },
  { icon: UserRound, label: "Meu cartão", path: "/cartao" },
  { icon: Settings, label: "Configurações", path: "/configuracoes" },
];

const SIDEBAR_WIDTH_KEY = "meu-autonomo-sidebar-width";
const DEFAULT_WIDTH = 260;
const MIN_WIDTH = 220;
const MAX_WIDTH = 360;

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [sidebarWidth, setSidebarWidth] = useState(() => {
    const saved = localStorage.getItem(SIDEBAR_WIDTH_KEY);
    return saved ? parseInt(saved, 10) : DEFAULT_WIDTH;
  });
  const { loading, user } = useAuth();

  useEffect(() => {
    localStorage.setItem(SIDEBAR_WIDTH_KEY, sidebarWidth.toString());
  }, [sidebarWidth]);

  if (loading) return <DashboardLayoutSkeleton />;
  if (!user) return null;

  return (
    <SidebarProvider style={{ "--sidebar-width": `${sidebarWidth}px` } as CSSProperties}>
      <DashboardLayoutContent setSidebarWidth={setSidebarWidth}>{children}</DashboardLayoutContent>
    </SidebarProvider>
  );
}

function DashboardLayoutContent({ children, setSidebarWidth }: { children: React.ReactNode; setSidebarWidth: (width: number) => void }) {
  const { user, logout } = useAuth();
  const { theme, setTheme } = useTheme();
  const [location, setLocation] = useLocation();
  const { state, toggleSidebar } = useSidebar();
  const isCollapsed = state === "collapsed";
  const isMobile = useIsMobile();
  const [isResizing, setIsResizing] = useState(false);
  const sidebarRef = useRef<HTMLDivElement>(null);
  const activeMenuItem = menuItems.find(item => item.path === location);
  const firstName = (user?.name || "profissional").split(" ")[0];

  useEffect(() => {
    const move = (event: MouseEvent) => {
      if (!isResizing) return;
      const left = sidebarRef.current?.getBoundingClientRect().left ?? 0;
      const width = event.clientX - left;
      if (width >= MIN_WIDTH && width <= MAX_WIDTH) setSidebarWidth(width);
    };
    const up = () => setIsResizing(false);
    if (isResizing) {
      document.addEventListener("mousemove", move);
      document.addEventListener("mouseup", up);
      document.body.style.cursor = "col-resize";
      document.body.style.userSelect = "none";
    }
    return () => {
      document.removeEventListener("mousemove", move);
      document.removeEventListener("mouseup", up);
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    };
  }, [isResizing, setSidebarWidth]);

  return (
    <>
      <div className="relative" ref={sidebarRef}>
        <Sidebar collapsible="icon" className="border-r-0 bg-[#132a27] text-[#f4f7f1]" disableTransition={isResizing}>
          <SidebarHeader className="h-20 justify-center border-b border-white/10">
            <div className="flex w-full items-center gap-3 px-2">
              <button onClick={toggleSidebar} className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-white/10 transition hover:bg-white/15" aria-label="Recolher menu">
                <PanelLeft className="h-4 w-4" />
              </button>
              {!isCollapsed && <Link href="/app" className="flex min-w-0 items-center gap-2">
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-[#d9f56a] text-[#132a27]"><Sparkles className="h-4 w-4" /></span>
                <span className="truncate text-base font-bold tracking-tight">MeuAutônomo</span>
              </Link>}
            </div>
          </SidebarHeader>
          <SidebarContent className="gap-0 px-2 py-4">
            <p className="mb-3 px-3 text-[10px] font-semibold uppercase tracking-[0.18em] text-white/45 group-data-[collapsible=icon]:hidden">Seu espaço</p>
            <SidebarMenu className="gap-1">
              {menuItems.map(item => {
                const active = location === item.path;
                return <SidebarMenuItem key={item.path}>
                  <SidebarMenuButton isActive={active} onClick={() => setLocation(item.path)} tooltip={item.label} className={`h-11 rounded-xl font-medium transition ${active ? "bg-[#d9f56a] text-[#132a27] hover:bg-[#d9f56a] hover:text-[#132a27]" : "text-white/70 hover:bg-white/10 hover:text-white"}`}>
                    <item.icon className="h-[18px] w-[18px] shrink-0" />
                    <span>{item.label}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>;
              })}
            </SidebarMenu>
          </SidebarContent>
          <SidebarFooter className="border-t border-white/10 p-3">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex w-full items-center gap-3 rounded-xl p-2 text-left transition hover:bg-white/10 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#d9f56a] group-data-[collapsible=icon]:justify-center">
                  <Avatar className="h-9 w-9 border border-white/20 bg-white/10"><AvatarFallback className="bg-[#d9f56a] text-[#132a27]">{firstName.charAt(0).toUpperCase()}</AvatarFallback></Avatar>
                  <div className="min-w-0 flex-1 group-data-[collapsible=icon]:hidden"><p className="truncate text-sm font-semibold">{user?.name || "Profissional"}</p><p className="mt-0.5 truncate text-xs text-white/50">{user?.email || "Minha conta"}</p></div>
                  <Menu className="h-4 w-4 text-white/50 group-data-[collapsible=icon]:hidden" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-60"><p className="px-2 py-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Aparência</p><DropdownMenuItem onClick={() => setTheme("light")} className="cursor-pointer"><SunMedium className="mr-2 h-4 w-4" /> Claro {theme === "light" && <span className="ml-auto text-xs text-[#8aa500]">Ativo</span>}</DropdownMenuItem><DropdownMenuItem onClick={() => setTheme("dark")} className="cursor-pointer"><Moon className="mr-2 h-4 w-4" /> Escuro {theme === "dark" && <span className="ml-auto text-xs text-[#8aa500]">Ativo</span>}</DropdownMenuItem><DropdownMenuItem onClick={() => setTheme("system")} className="cursor-pointer"><Monitor className="mr-2 h-4 w-4" /> Automático {theme === "system" && <span className="ml-auto text-xs text-[#8aa500]">Ativo</span>}</DropdownMenuItem><DropdownMenuItem onClick={logout} className="cursor-pointer text-destructive focus:text-destructive"><LogOut className="mr-2 h-4 w-4" /> Sair da conta</DropdownMenuItem></DropdownMenuContent>
            </DropdownMenu>
          </SidebarFooter>
        </Sidebar>
        <div className={`absolute right-0 top-0 z-50 h-full w-1 cursor-col-resize transition hover:bg-[#d9f56a]/40 ${isCollapsed ? "hidden" : ""}`} onMouseDown={() => setIsResizing(true)} />
      </div>
      <SidebarInset className="bg-[#f5f7f2]">
        <div className="sticky top-0 z-40 flex h-16 items-center justify-between border-b border-[#dce5dc] bg-[#f5f7f2]/90 px-4 backdrop-blur md:px-8">
          <div className="flex items-center gap-3"><SidebarTrigger className="h-9 w-9 rounded-xl bg-white md:hidden" /><span className="text-sm font-medium text-[#58716b]">{activeMenuItem?.label || "Visão geral"}</span></div>
          <div className="flex items-center gap-3"><span className="hidden text-right text-xs text-[#58716b] sm:block">Bom dia, <strong className="text-[#173a34]">{firstName}</strong></span><NotificationsBell /><div className="grid h-9 w-9 place-items-center rounded-full bg-[#d9f56a] text-sm font-bold text-[#173a34]">{firstName.charAt(0).toUpperCase()}</div></div>
        </div>
        <main className="min-h-[calc(100vh-4rem)] flex-1 pb-24">{children}</main>
        {isMobile && <nav className="fixed bottom-0 left-0 right-0 z-50 flex h-[72px] items-center justify-around border-t border-[#dce5dc] bg-white/95 px-2 shadow-[0_-6px_20px_rgba(19,42,39,0.06)] backdrop-blur">
          {menuItems.slice(0, 5).map(item => { const active = location === item.path; return <button key={item.path} onClick={() => setLocation(item.path)} className={`flex min-w-0 flex-col items-center gap-1 rounded-xl px-3 py-2 text-[10px] font-semibold ${active ? "text-[#173a34]" : "text-[#8a9b95]"}`}><item.icon className={`h-5 w-5 ${active ? "text-[#8aa500]" : ""}`} /><span className="truncate">{item.label}</span></button>; })}
        </nav>}
      </SidebarInset>
    </>
  );
}

function NotificationsBell() {
  const notifications = trpc.notification.list.useQuery();
  const unread = trpc.notification.unreadCount.useQuery();
  const markRead = trpc.notification.markRead.useMutation({ onSuccess: () => { notifications.refetch(); unread.refetch(); } });
  return <DropdownMenu><DropdownMenuTrigger asChild><button aria-label="Notificações" className="relative grid h-9 w-9 place-items-center rounded-xl text-[#58716b] transition hover:bg-white"><Bell className="h-4 w-4" />{(unread.data || 0) > 0 && <span className="absolute right-1 top-1 h-2 w-2 rounded-full bg-[#9c4d43]" />}</button></DropdownMenuTrigger><DropdownMenuContent align="end" className="w-80"><p className="px-2 py-2 text-sm font-bold text-[#173a34]">Notificações</p>{notifications.data?.length ? notifications.data.map(item => <DropdownMenuItem key={item.id} onClick={() => !item.read && markRead.mutate({ id: item.id })} className="cursor-pointer items-start gap-2 py-3"><span className={item.read ? "mt-1 h-2 w-2 rounded-full bg-[#dce5dc]" : "mt-1 h-2 w-2 rounded-full bg-[#d9f56a]"} /><span><strong className="block text-xs text-[#284b42]">{item.title}</strong><span className="mt-1 block text-xs text-[#82948e]">{item.body}</span></span></DropdownMenuItem>) : <p className="px-2 py-4 text-xs text-[#82948e]">Nenhuma notificação por enquanto.</p>}</DropdownMenuContent></DropdownMenu>;
}
